#pragma once

#include <utility>
#include <string>

std::pair<std::string, int> getPyError();
bool isPyKeyword(std::string k);
