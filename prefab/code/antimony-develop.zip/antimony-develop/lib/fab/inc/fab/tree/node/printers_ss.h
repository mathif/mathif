#ifndef PRINTERS_SS_H
#define PRINTERS_SS_H

#include <string>

struct Node_;
std::string print_node_ss(struct Node_* node);

#endif

