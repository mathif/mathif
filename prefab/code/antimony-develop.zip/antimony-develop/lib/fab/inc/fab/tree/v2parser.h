#include "fab/tree/tree.h"
#include "fab/tree/parser.h"
#include "fab/tree/node/node.h"

bool v2parse(Node **result, const char* input, Node* X, Node* Y, Node *Z, NodeCache* cache);
